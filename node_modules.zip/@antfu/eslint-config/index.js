module.exports = {
  extends: [
    '@antfu/eslint-config-vue',
  ],
}
