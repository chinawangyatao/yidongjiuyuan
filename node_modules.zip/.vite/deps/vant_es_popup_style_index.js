// node_modules/vant/es/popup/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/badge/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/icon/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/overlay/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/popup/index.css";
//# sourceMappingURL=vant_es_popup_style_index.js.map
