// node_modules/vant/es/divider/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/divider/index.css";
//# sourceMappingURL=vant_es_divider_style_index.js.map
