// node_modules/vant/es/empty/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/empty/index.css";
//# sourceMappingURL=vant_es_empty_style_index.js.map
