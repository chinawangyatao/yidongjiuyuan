// node_modules/vant/es/config-provider/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
//# sourceMappingURL=vant_es_config-provider_style_index.js.map
