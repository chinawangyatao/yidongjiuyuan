import {
  __commonJS
} from "./chunk-IN47U6CF.js";

// browser-external:events
var require_events = __commonJS({
  "browser-external:events"(exports, module) {
    module.exports = Object.create(new Proxy({}, {
      get(_, key) {
        if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") {
          console.warn(`Module "events" has been externalized for browser compatibility. Cannot access "events.${key}" in client code.`);
        }
      }
    }));
  }
});

export {
  require_events
};
//# sourceMappingURL=chunk-PQCMVZME.js.map
