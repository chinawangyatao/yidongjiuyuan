// node_modules/vant/es/dropdown-menu/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/dropdown-menu/index.css";
//# sourceMappingURL=vant_es_dropdown-menu_style_index.js.map
