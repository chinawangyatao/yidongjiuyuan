// node_modules/vant/es/image/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/badge/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/icon/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/image/index.css";
//# sourceMappingURL=vant_es_image_style_index.js.map
