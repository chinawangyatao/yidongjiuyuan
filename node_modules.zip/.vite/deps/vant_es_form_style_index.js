// node_modules/vant/es/form/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
//# sourceMappingURL=vant_es_form_style_index.js.map
