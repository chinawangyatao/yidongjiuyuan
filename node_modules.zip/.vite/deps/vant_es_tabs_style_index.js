// node_modules/vant/es/tabs/style/index.mjs
import "D:/index-demo/移动救援/node_modules/vant/es/style/base.css";
import "D:/index-demo/移动救援/node_modules/vant/es/badge/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/sticky/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/swipe/index.css";
import "D:/index-demo/移动救援/node_modules/vant/es/tabs/index.css";
//# sourceMappingURL=vant_es_tabs_style_index.js.map
