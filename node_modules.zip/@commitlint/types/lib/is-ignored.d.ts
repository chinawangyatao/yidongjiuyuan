export declare type Matcher = (commit: string) => boolean;
export interface IsIgnoredOptions {
    ignores?: Matcher[];
    defaults?: boolean;
}
//# sourceMappingURL=is-ignored.d.ts.map